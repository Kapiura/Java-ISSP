public record Pair<K, V>(K key, V value)
{
}
// w java nie ma pary wiec trza sobie samemu zrobic #zalosne
